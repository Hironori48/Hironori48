# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '885baf4f28a0f07651adab3a2c7355607d2ebed0e2c6af638bf9aee936d59a320889e6bc831b3030fec90cf49b1a156a0005081074e25e8101bf84c626c47603'