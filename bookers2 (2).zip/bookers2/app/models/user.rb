class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable

  attachment :profile_image

  has_many :books, dependent: :destroy

  validates :name, uniqueness: { message: 'そのnameは使用できません' },
  confirmation: true,
  length: { minimum: 3, too_shott: "%{count}文字以下は使えません", maximum: 20, too_long: "最大%{count}文字まで使えます" }

  validates :introduction, length: { maximum: 50, too_long: "最大%{count}文字まで使えます" }
end
