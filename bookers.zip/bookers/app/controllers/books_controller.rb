class BooksController < ApplicationController

  def index
    @book = Book.new
    @books = Book.all
  end

  def new
      @book = Book.find(params[:id])
  end

  def show
    @book = Book.find(params[:id])
  end

  def create
    @book = Book.new(list_params)
    # book.save
    # redirect_to index_book_path
    if @book.save
      # redirect_to index_book_path
      redirect_to new_book_path(@book.id)
    else
      @books = Book.all
      render :index
    end
  end

  def edit
    @book = Book.find(params[:id])
  end

  def update
    @book = Book.find(params[:id])

    if @book.update(list_params)
      redirect_to show_book_path(@book.id)
    else
      render :edit
    end
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
    redirect_to index_book_path
  end

  private

  def list_params
    params.require(:book).permit(:title, :body)
  end

end
